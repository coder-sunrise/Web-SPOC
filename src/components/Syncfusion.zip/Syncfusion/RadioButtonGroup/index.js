import React from 'react'
import { ButtonComponent, RadioButtonComponent } from '@syncfusion/ej2-react-buttons'

class RadioButtonGroup extends React.Component {
    constructor (props) {
      super(props)
    }
    
    render () {
        const {label,children=[], name}=this.props
        // const opts={
        //     ...floatLabelType==='Never'?{placeholder}:{},
        //     ...floatLabelType==='Auto'?{required:true}:{},

        // }
        const opts={
          name,
          
        }
      return <div className='control-pane'>
        <div className='control-section'>
          <div className='radiobutton-control e-float-input e-control-wrapper' style={{paddingTop: label?30:0}}>
            {label && <label className='e-float-text'>{label}</label>}
            {children.map((o)=>{
              console.log(o)
              // o.props={
              //   ...o.proprs,
              //   ...opts,
              //   key:o.value,
              // }
              const n=React.cloneElement(
                o,
                opts
              )
              console.log(n)
              return <div className='row' key={o.value}>
                {n}
                     </div>
            })}
          </div>
        </div>
             </div>
    }  
  }
  

  export default RadioButtonGroup