import * as React from 'react'
import ReactDOM from 'react-dom'
import { TextBox } from '@syncfusion/ej2-inputs'
import { ComponentBase, applyMixins } from '@syncfusion/ej2-react-base'

let __extends = (this && this.__extends) || (function () {
    let extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b }) ||
            function (d, b) { for (let p in b) if (b.hasOwnProperty(p)) d[p] = b[p] }
        return extendStatics(d, b)
    }
    return function (d, b) {
        extendStatics(d, b)
        function __ () { this.constructor = d }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __())
    }
})()
/**
 * Represents the React TextBox Component
 * ```html
 * <TextBox value={value}></TextBox>
 * ```
 */
const TextBoxComponent = /** @class */ (function (_super) {
    // console.log(_super)
    __extends(TextBoxComponent, _super)
    function TextBoxComponent (props) {
        let _this = _super.call(this, props) || this
        _this.initRenderCalled = false
        _this.checkInjectedModules = false
        return _this
    }
    TextBoxComponent.prototype.render = function () {
        if ((this.element && !this.initRenderCalled) || this.refreshing) {
            _super.prototype.render.call(this)
            // console.log(this)
            const {props}=this
            const {icon}=props
            if(icon){
                const _container = document.createElement('div')
                _container.setAttribute("style", "float:right; top: 25%; right: 0px;position:absolute;cursor:pointer;")
                const _iconWarpper = document.createElement('span')
                _iconWarpper.classList.add('e-input-group-icon')
                _container.appendChild(_iconWarpper)
                ReactDOM.render(icon, _iconWarpper)
                this.textboxWrapper.container.appendChild(_container)
            }
            this.initRenderCalled = true
        }
        else {
            return React.createElement('input', this.getDefaultAttributes())
        }
    }
    return TextBoxComponent
}(TextBox))
export { TextBoxComponent }
applyMixins(TextBoxComponent, [ComponentBase, React.PureComponent])
