import _extends from 'babel-runtime/helpers/extends'
import React, { Component } from 'react'
import ReactDOM from 'react-dom'
import { ToastComponent } from '@syncfusion/ej2-react-notifications'

let defaultTop = 24
let defaultBottom = 24
let defaultPlacement ={
    X:'Center',
    Y:'Top',
}
let defaultGetContainer
let _toastInstance
let _container

function notice (args) {
    args.position  = args.position === undefined ? defaultPlacement : args.position

    if(!_toastInstance){
        _container = document.createElement('div')
        if (args.getContainer) {
          let root = args.getContainer()
          root.appendChild(_container)
        } else {
          document.body.appendChild(_container)
        }
      
        ReactDOM.render(<ToastComponent 
          ref={toast =>{
            _toastInstance = toast
          }}
          created={el=> {
              _toastInstance.show(args)             
          }}
          click={(e)=> e.clickToClose = true}
          {...args}

        />, _container)
    }else{
        _toastInstance.show(args)
    }
}

const api = {
    open: notice,
    close: function close (key) {
        _toastInstance.hide()
    },

    destroy: function destroy () {
        ReactDOM.unmountComponentAtNode(_container)
        _container.parentNode.removeChild(_container)
    },
};
['success', 'info', 'warning', 'error'].forEach((type) => {
    api[type] = function (args) {
        if(typeof args === 'string'){
            args={
                content:args,
            }
        }
        return api.open(_extends({}, args, { 
            type,
            ...{
                info:  { title:'Information!', cssClass: 'e-toast-info', icon: 'e-info toast-icons', timeOut:4500 },
                success: {  title:'Success!',cssClass: 'e-toast-success', icon: 'e-success toast-icons', timeOut:4500 },
                error: {title:'Error!', cssClass: 'e-toast-danger', icon: 'e-error toast-icons', timeOut:0 },
                warning: {  title:'Warning!',cssClass: 'e-toast-warning', icon: 'e-warning toast-icons', timeOut:10000 },
                loading: 'loading',
            }[type],
        }))
    }
})
api.warn = api.warning
export default api