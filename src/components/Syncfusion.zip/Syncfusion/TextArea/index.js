import React from 'react'

class TextArea extends React.Component {
    constructor (props) {
      super(props)
    }
    
    render () {
        const {floatLabelType='Never',placeholder}=this.props
        const opts={
            ...floatLabelType==='Never'?{placeholder}:{},
            ...floatLabelType==='Auto'?{required:true}:{},

        }
      return <div className="e-float-input">
        <textarea {...opts} />
        {
            floatLabelType!=='Never' &&<React.Fragment>
              <span className="e-float-line" />
              <label className="e-float-text">{placeholder}</label>
            </React.Fragment>
        }
      </div>
    }  
  }
  

  export default TextArea